"use strict";

const db = require("../db-connection");

module.exports = function (app) {
  app
    .route("/api/threads/:board")
    .post(async (req, res) => {
      const { text, delete_password } = req.body;
      const board = req.params.board;
      const now = new Date();
      
      try {
        const [thread] = await db('threads').insert({
          board,
          text,
          delete_password,
          created_on: now,
          bumped_on: now,
          reported: false
        }).returning('*');
        res.json(thread);
      } catch (err) {
        res.send("error creating thread");
      }
    })
    .get(async (req, res) => {
      const board = req.params.board;
      try {
        const threads = await db('threads')
          .where({ board })
          .orderBy('bumped_on', 'desc')
          .limit(10);
          
        const result = await Promise.all(threads.map(async (t) => {
          const replies = await db('replies')
            .where({ thread_id: t._id })
            .orderBy('created_on', 'desc')
            .limit(3)
            .select('_id', 'text', 'created_on');
            
          const [{ count }] = await db('replies')
            .where({ thread_id: t._id })
            .count('_id as count');

          return {
            _id: t._id,
            text: t.text,
            created_on: t.created_on,
            bumped_on: t.bumped_on,
            replies,
            replycount: parseInt(count)
          };
        }));
        res.json(result);
      } catch (err) {
        res.json([]);
      }
    })
    .put(async (req, res) => {
      const { thread_id, report_id } = req.body;
      const idToUpdate = thread_id || report_id;
      try {
        await db('threads').where({ _id: parseInt(idToUpdate) }).update({ reported: true });
        res.send("reported");
      } catch (err) {
        res.send("error reporting thread");
      }
    })
    .delete(async (req, res) => {
      const { thread_id, delete_password } = req.body;
      try {
        const thread = await db('threads').where({ _id: parseInt(thread_id) }).first();
        if (thread.delete_password === delete_password) {
          await db('threads').where({ _id: parseInt(thread_id) }).del();
          res.send("success");
        } else {
          res.send("incorrect password");
        }
      } catch (err) {
        res.send("error deleting thread");
      }
    });

  app
    .route("/api/replies/:board")
    .post(async (req, res) => {
      const { thread_id, text, delete_password } = req.body;
      const now = new Date();
      try {
        const [reply] = await db('replies').insert({
          thread_id: parseInt(thread_id),
          text,
          delete_password,
          created_on: now,
          reported: false
        }).returning('*');
        await db('threads').where({ _id: parseInt(thread_id) }).update({ bumped_on: now });
        res.json(reply);
      } catch (err) {
        res.send("error adding reply");
      }
    })
    .get(async (req, res) => {
      const { thread_id } = req.query;
      try {
        const thread = await db('threads').where({ _id: parseInt(thread_id) }).first();
        const replies = await db('replies')
          .where({ thread_id: parseInt(thread_id) })
          .select('_id', 'text', 'created_on');
        
        res.json({
          _id: thread._id,
          text: thread.text,
          created_on: thread.created_on,
          bumped_on: thread.bumped_on,
          replies
        });
      } catch (err) {
        res.json({ error: "thread not found" });
      }
    })
    .put(async (req, res) => {
      const { reply_id } = req.body;
      try {
        await db('replies').where({ _id: parseInt(reply_id) }).update({ reported: true });
        res.send("reported");
      } catch (err) {
        res.send("error reporting reply");
      }
    })
    .delete(async (req, res) => {
      const { reply_id, delete_password } = req.body;
      try {
        const reply = await db('replies').where({ _id: parseInt(reply_id) }).first();
        if (reply.delete_password === delete_password) {
          await db('replies').where({ _id: parseInt(reply_id) }).update({ text: "[deleted]" });
          res.send("success");
        } else {
          res.send("incorrect password");
        }
      } catch (err) {
        res.send("error deleting reply");
      }
    });
};
