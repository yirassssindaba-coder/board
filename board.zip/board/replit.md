# Anonymous Message Board

## Overview

This is a freeCodeCamp Information Security project that implements an anonymous message board API. Users can create boards, post threads, reply to threads, report content, and delete their own posts using passwords. The application serves both a REST API and simple HTML frontend views for interacting with the message board.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Framework
- **Express.js** serves as the web framework
- Node.js runtime with ES5 strict mode conventions
- Body-parser handles JSON and URL-encoded form data

### Database Layer
The project uses **PostgreSQL with Knex.js** as the primary data store.
- `threads` - stores board name, text, delete_password, timestamps, reported status
- `replies` - stores thread_id reference, text, delete_password, timestamps, reported status

Schemas are initialized via startup scripts.

### Recent Changes
- Migrated database from MongoDB to PostgreSQL.
- Removed legacy Mongoose models.
- Updated security features using Helmet.js.
- Refactored API routes to use async/await and Knex.
- **January 2026**: Security dependency updates - Updated all major dependencies (body-parser, express, helmet, chai, chai-http, mocha, mongoose, mongodb, nodemon, dotenv, cors) to latest versions to address security vulnerabilities including issues with ansi-regex, braces, debug, minimatch, minimist, qs, semver, path-to-regexp, and others. Removed deprecated helmet.xssFilter() call for Helmet v8 compatibility.